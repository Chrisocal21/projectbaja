# Off-Road Build — Vehicle 001 Asset Inspector

A standalone Vite + React 18 + React Three Fiber / Three.js viewer, bundled with **all 17 GLB blockout assets** created so far.

## Run

1. Install Node.js 18+.
2. Open this folder in VS Code.
3. In its terminal run `npm install`, then `npm run dev`.
4. Open the local URL printed by Vite (usually http://localhost:5173).

To check a production build: `npm run build`.

## Features
- Orbit / zoom / pan / reset camera
- Stock, Trail, Baja presets
- Individual on/off toggles for 16 modular upgrade GLBs
- Automatically hides relevant stock meshes when swapping fenders, hood, wheels, bumper, etc.
- Prevents enabling both alternative fender types or duplicate shock assemblies simultaneously
- Click a mesh to see its actual node name, source GLB, triangle count and bounding dimensions
- Wireframe, grid and autorotation controls

## Notes / limitations
- **Geometry-only v0.1 blockouts**. Not final production-ready 3D models.
- GLBs share a vehicle coordinate frame: meters, +Y up, +Z forward.
- Base model has continuous body geometry under replacement parts. Even if stock meshes are hidden, expect occlusion/overlap. Engine and cage may not be visibly exposed until actual cutouts are modeled.
- Presets are convenient *visual previews*, not game design or upgrade logic.
- For source code in your existing app, use `src/main.jsx` as reference and copy `public/models` as needed.
