import React, { Suspense, useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Canvas, useThree } from '@react-three/fiber';
import { Bounds, ContactShadows, Environment, Grid, OrbitControls, useGLTF } from '@react-three/drei';
import * as THREE from 'three';
import './style.css';

const ASSETS = [
  ['PART_001_AllTerrainWheelSet', 'All-terrain wheels', 'Wheels'],
  ['PART_002_FrontTubeBumper', 'Front tube bumper', 'Protection'],
  ['PART_003_RearEngineCage', 'Rear engine cage', 'Protection'],
  ['PART_004_BumperAuxLights', 'Auxiliary lights', 'Lighting'],
  ['PART_005_FrontSkidPlate', 'Front skid plate', 'Protection'],
  ['PART_006_TrailShockSet', 'Trail shocks', 'Mechanical'],
  ['PART_007_CutBajaFenders', 'Cut Baja fenders', 'Body'],
  ['PART_008_ShortenedFrontHood', 'Shortened front hood', 'Body'],
  ['PART_009_RearEngineOpening', 'Rear engine opening', 'Body'],
  ['PART_010_FiberglassWideFenders', 'Wide fiberglass fenders', 'Body'],
  ['PART_011_RockerGuards', 'Rocker guards', 'Protection'],
  ['PART_012_AirCooledRearEngine', 'Rear air-cooled engine', 'Mechanical'],
  ['PART_013_SuspensionAssembly', 'Suspension assembly', 'Mechanical'],
  ['PART_014_InteriorRollCage', 'Interior roll cage', 'Cage'],
  ['PART_015_FrontCageReinforcement', 'Front cage reinforcement', 'Cage'],
  ['PART_016_RearCageBracing', 'Rear cage bracing', 'Cage'],
].map(([id,label,category])=>({id,label,category}));
const categories = ['Wheels','Body','Protection','Mechanical','Cage','Lighting'];
const empty = {};
const builds = {
  'Stock': {},
  'Trail': Object.fromEntries([0,1,3,4,5,6,7,10].map(i=>[ASSETS[i].id,true])),
  'Baja': Object.fromEntries([0,1,2,3,4,7,8,10,11,12,13,14,15].map(i=>[ASSETS[i].id,true]))
};
const stockMasks = {
  PART_001_AllTerrainWheelSet: ['WHEEL_'],
  PART_002_FrontTubeBumper: ['EXTERIOR_Bumper_Front','EXTERIOR_Overrider_Front_'],
  PART_003_RearEngineCage: [],
  PART_006_TrailShockSet: [],
  PART_007_CutBajaFenders: ['BODY_Fender_'],
  PART_008_ShortenedFrontHood: ['BODY_Hood_Front','TRIM_HoodCenter'],
  PART_009_RearEngineOpening: ['BODY_Engine_Lid_Rear'],
  PART_010_FiberglassWideFenders: ['BODY_Fender_'],
  PART_011_RockerGuards: ['TRIM_RunningBoard_'],
};
function maskFor(enabled) {
  let mask = [];
  for (const id of Object.keys(enabled)) if(enabled[id]) mask.push(...(stockMasks[id]||[]));
  return mask;
}
function Model({file, mask=[], wireframe, onSelect, isBase=false}) {
  const {scene} = useGLTF(`/models/${file}.glb`);
  const clone = useMemo(()=>{
    const c = scene.clone(true);
    c.traverse(o=>{ if(o.isMesh) {
      o.material = Array.isArray(o.material) ? o.material.map(m=>m.clone()) : o.material?.clone();
    }});
    return c;
  },[scene]);
  useEffect(()=>{
    clone.traverse(o=>{if(!o.isMesh)return;
      o.visible = !(isBase && mask.some(prefix=>o.name.startsWith(prefix)));
      const mats = Array.isArray(o.material) ? o.material:[o.material];
      mats.forEach(m=>{if(m) m.wireframe=wireframe;});
    });
  },[clone,mask.join('|'),wireframe,isBase]);
  return <primitive object={clone} onClick={e=>{
    e.stopPropagation();
    const m=e.object; const box = new THREE.Box3().setFromObject(m);
    const size = box.getSize(new THREE.Vector3());
    onSelect({name:m.name||'(unnamed mesh)',asset:file,triangles:Math.round((m.geometry?.index?.count||m.geometry?.attributes?.position?.count||0)/3),size:[size.x,size.y,size.z].map(n=>n.toFixed(2))});
  }}/>
}
function CameraReset({resetKey}) {
  const {camera,controls} = useThree();
  useEffect(()=>{camera.position.set(5.9,3.15,6.6); controls?.target.set(0,0.8,0);controls?.update();},[camera,controls,resetKey]);
  return null;
}
function Stage({enabled,wireframe,autoRotate,resetKey,onSelect,showGrid}) {
  const masks = useMemo(()=>maskFor(enabled),[enabled]);
  return <Canvas shadows camera={{position:[5.9,3.15,6.6],fov:43,near:0.05,far:100}} dpr={[1,2]} onPointerMissed={()=>onSelect(null)}>
    <color attach="background" args={['#172124']}/>
    <ambientLight intensity={1.25}/><hemisphereLight args={['#e6e9d5','#384348',1.7]}/>
    <directionalLight position={[5,9,4]} intensity={2.3} castShadow shadow-mapSize={[1024,1024]}/>
    <directionalLight position={[-4,3,-4]} intensity={1.2}/>
    <Suspense fallback={null}>
      <Model file="VEH_001_Bug_Base_v01" mask={masks} wireframe={wireframe} onSelect={onSelect} isBase/>
      {ASSETS.filter(a=>enabled[a.id]).map(a=><Model key={a.id} file={a.id} wireframe={wireframe} onSelect={onSelect}/>)}
    </Suspense>
    {showGrid && <Grid position={[0,-0.035,0]} args={[30,30]} cellSize={0.5} sectionSize={2} cellColor="#546365" sectionColor="#748587" fadeDistance={22} fadeStrength={2} infiniteGrid/>}
    <OrbitControls makeDefault autoRotate={autoRotate} autoRotateSpeed={1.2} minDistance={2.7} maxDistance={18} maxPolarAngle={Math.PI/2.05} target={[0,0.8,0]}/>
    <CameraReset resetKey={resetKey}/>
  </Canvas>
}
function App(){
 const [enabled,setEnabled]=useState({}); const [mode,setMode]=useState('Stock');
 const [wireframe,setWireframe]=useState(false),[spin,setSpin]=useState(false),[grid,setGrid]=useState(true);
 const [resetKey,setResetKey]=useState(0),[selected,setSelected]=useState(null),[filter,setFilter]=useState('All');
 const turnOn=(id)=>{setMode('Custom');setSelected(null);setEnabled(old=>{
   const next={...old,[id]:!old[id]};
   // These alternative panel sets should not appear together.
   if(next[id]&&id==='PART_007_CutBajaFenders')next.PART_010_FiberglassWideFenders=false;
   if(next[id]&&id==='PART_010_FiberglassWideFenders')next.PART_007_CutBajaFenders=false;
   if(next[id]&&id==='PART_013_SuspensionAssembly')next.PART_006_TrailShockSet=false;
   if(next[id]&&id==='PART_006_TrailShockSet')next.PART_013_SuspensionAssembly=false;
   return next;
 });};
 const applyPreset=(name)=>{setMode(name);setEnabled(builds[name]);setSelected(null);};
 const active=ASSETS.filter(a=>enabled[a.id]).length;
 return <div className="shell">
   <aside className="sidebar">
     <header><span className="eyebrow">OFF-ROAD BUILD • ASSET LAB</span><h1>VEH_001 <span>/ Classic Bug</span></h1><p>Modular 3D inspector · Three.js / R3F</p></header>
     <div className="section"><div className="section-title">BUILD PRESETS</div><div className="presets">{Object.keys(builds).map(b=><button key={b} className={mode===b?'active':''} onClick={()=>applyPreset(b)}>{b}</button>)}</div></div>
     <div className="section parts-head"><div className="section-title">UPGRADE PARTS <span>{active} active</span></div><div className="filters"><button className={filter==='All'?'current':''} onClick={()=>setFilter('All')}>All</button>{categories.map(c=><button className={filter===c?'current':''} key={c} onClick={()=>setFilter(c)}>{c}</button>)}</div></div>
     <div className="parts">{ASSETS.filter(a=>filter==='All'||a.category===filter).map(a=><label key={a.id} className="part"><span><strong>{a.label}</strong><small>{a.id.replace('PART_','').slice(0,3)} · {a.category}</small></span><input type="checkbox" checked={!!enabled[a.id]} onChange={()=>turnOn(a.id)}/></label>)}</div>
     <div className="aside-foot">16 upgrade GLBs + 1 base vehicle<br/>Model units: meters · +Z forward</div>
   </aside>
   <main className="main"><div className="topbar"><div><strong>3D VEHICLE VIEW</strong><span>Drag rotate · Scroll zoom · Right-click pan · Click mesh inspect</span></div><div className="toolbar"><button onClick={()=>setResetKey(k=>k+1)}>Reset camera</button><button className={spin?'toggled':''} onClick={()=>setSpin(s=>!s)}>Auto rotate</button><button className={wireframe?'toggled':''} onClick={()=>setWireframe(w=>!w)}>Wireframe</button><button className={grid?'toggled':''} onClick={()=>setGrid(g=>!g)}>Grid</button></div></div>
     <div className="viewport"><Stage enabled={enabled} wireframe={wireframe} autoRotate={spin} showGrid={grid} resetKey={resetKey} onSelect={setSelected}/><div className="view-label">VEH_001_Bug_Base_v01 <span>BLOCKOUT / NOT FINAL</span></div></div>
     <div className="details"><div><span className="eyebrow">MESH INSPECTOR</span>{selected?<><h2>{selected.name}</h2><p>Source: {selected.asset}.glb</p><div className="statline"><span>{selected.triangles.toLocaleString()} tris</span><span>Bounds {selected.size.join(' × ')} m</span></div></>:<><h2>Select a component</h2><p>Click any visible mesh to inspect its name, source and dimensions.</p></>}</div><div className="status"><span className="eyebrow">ASSEMBLY STATUS</span><strong>{active} / 16</strong><p>Upgrades enabled</p><small>Visual-fit review needed. Overlap and blocked engine/cage details are expected in v0.1.</small></div></div>
   </main>
 </div>;
}
createRoot(document.getElementById('root')).render(<App/>);
