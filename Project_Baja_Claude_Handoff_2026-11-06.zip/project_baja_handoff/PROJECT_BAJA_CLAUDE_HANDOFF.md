# PROJECT: BAJA — CLAUDE.AI / THE FORGE HANDOFF
Date: November 6, 2026
Status: Provisional working title; changeable.

## HOW TO USE THIS HANDOFF
This is a context and asset handoff, not a request to redesign the game. Read this alongside the existing Forge documents. Treat established Forge decisions as authoritative. Identify conflicts with the Forge's latest records rather than silently overwriting them. Update living documentation only as consistent with the Forge workflow, then prepare a focused VS Code / Claude Code implementation task.

## OWNERSHIP / ROLES
- The Forge in Claude.ai owns scope, game design, milestones, decisions and the living documents: FEATURE_MAP, PROGRESS_TRACKER, OPEN_QUESTIONS, PROJECT_LOG and CLAUDE_GUIDE. Nora coordinates the team. Claude.ai is not the code implementation environment.
- Claude Code / VS Code implements and tests code. The Workshop can be used for UI prototypes.
- ChatGPT has been supporting visual direction, concept art, procedural 3D blockouts, reference assets, and a preliminary viewer.
- Source-of-truth priority: live GitHub repository and Vercel deployment > newest actual implementation summary > older Forge snapshot. The Forge cannot directly observe GitHub; send back verified Claude Code session summaries.

## GAME IDENTITY / SETTLED BRIEF
Working title: PROJECT: BAJA (not final). Separate from Salvage Road. Do not bring over Salvage Road's lonely post-apocalyptic style or branding.
Open-world off-road vehicle building/trading game in Southern California and Baja Mexico, with lived-in towns, coastal roads, dry lakebeds, desert, mountains and border-region environment. Players acquire, improve and sell vehicles; classic Bugs, buggies, trucks, and later bikes are part of the wider visual scope. Racing is a later-phase item. The central fantasy is that the vehicle visibly tells the story of what the player found, repaired, bought and built.
Parts sources already discussed: ordinary paid-business junkyards, unmarked barn finds discovered by exploration, and later-phase racing rewards. Marketplace concept: player lists builds as on a classified/off-road forum; appraisal and NPC offers. These are already settled context, not requests for engineering or mechanics proposals.

## CONFIRMED VISUAL DIRECTION
- Grounded semi-realism; realistic vehicle proportions and mechanical detailing, slightly simplified but believable environments.
- Authentic workshop finish: chalky sun-faded paint, primer replacements, dusty glass and rubber, metal wear, convincing welds, aged chrome, surface corrosion, grime, repaired components.
- Lived-in SoCal / Baja, normal shops and junkyards, natural warm afternoon lighting. Avoid excessive bloom, exaggerated stylization or survival/post-apocalypse clichés.
- Visual brand palette (not limits on paint): sand #C4A574; clay #A46A4B; sage #778571; graphite #353B40; cream #E5DDD0; orange #DC652D.
- The working tagline 'Built, Not Bought' is optional concept copy, NOT an approved final brand promise.

## STARTER VEHICLE / STORY CONTEXT
VEH_001: a classic, vintage rounded two-door, rear-engine, air-cooled Bug-inspired compact car. Original unbranded final design; not a modern Fiat-style compact. The player purchases an old, beat-up project car from a seller at an ordinary small-town mechanic yard and makes it roadworthy with a tune-up and fluids rather than doing a total rebuild immediately. It should still look worn after initial maintenance. Over time the player finds parts and visibly converts the classic Bug into a Baja Bug.
Original-for-sale appearance: faded blue paint (#739CA6), matte primer-gray **front-left** fender (#777A78), slightly crooked aged chrome bumper, narrow old steel wheels, street tires, dusty windows, oxidized hood/roof, small dents, worn seals, aged tan cabin. Seller setting: open repair bays, tools, cracked asphalt, parked vehicles, modest mountains/palms in the background, warm afternoon light.
Visual progression: stock worn project car -> early trail beater -> recognizable Baja conversion -> capable desert Baja. This is art direction; do not infer unapproved upgrade mechanics.

## TECHNICAL ASSET CONVENTIONS
Engine/render target: Three.js with React Three Fiber. Primary asset format: GLB/glTF 2.0; PBR metallic-roughness; meters, +Y up, local +Z forward; stable names and modular replaceable parts. Initial modeled vehicle envelope around 4.1m long x 1.6m wide x 1.5m tall (provisional, visually verify). The early exterior geometry target of 20k–40k triangles is a planning guideline, not a measured finished asset budget. Distinct doors, hood, rear lid, fenders, body, bumpers, trims, and eventual wheels/suspension. Inspect pivot positions and assembly fit.

## AVAILABLE FILES (IN THE ATTACHED HANDOFF PACKAGE)
- OffRoad_Bug_Asset_Viewer_v01.zip: a working-source **prototype**, not browser-verified. Vite + React 18 + Three.js + R3F + Drei; includes 17 GLBs in public/models. Features orbit, zoom/pan/reset, stock/trail/Baja preview presets, part toggles, automatic hiding of some stock meshes, mesh click inspector, wireframe and grid. package.json currently uses Vite 5, React 18, R3F 8, Drei 9, Three 0.170; check compatibility during install. Viewer UI currently has generic 'Off-Road Build' wording; rename user-facing identity to Project: Baja.
- bug_asset/VEH_001_Bug_Base_v01.glb — initial stock vehicle procedural geometry blockout.
- bug_asset/PART_001 through PART_016 — 16 modular upgrade blockouts:
  001 AllTerrainWheelSet
  002 FrontTubeBumper
  003 RearEngineCage
  004 BumperAuxLights
  005 FrontSkidPlate
  006 TrailShockSet
  007 CutBajaFenders
  008 ShortenedFrontHood
  009 RearEngineOpening
  010 FiberglassWideFenders
  011 RockerGuards
  012 AirCooledRearEngine
  013 SuspensionAssembly
  014 InteriorRollCage
  015 FrontCageReinforcement
  016 RearCageBracing
- bug_asset/*.py — procedural generators to revise these blockouts, not artist-authored final meshes.
- reference_images/starter_bug_mechanic_yard.png — original faded-blue mechanic-yard starter vehicle concept; primary appearance reference.
- reference_images/modular_asset_sheet.png — mesh breakdown + views; conceptual only.
- reference_images/vehicle_turnaround_sheet.png — surfaces and views; has ERRONEOUS 'SALVAGE ROAD' text; use only the car imagery, not that branding.
- reference_images/project_baja_poster_concept.png — temporary art exploration titled 'Off-Road Build'; not an approved final game logo/title.

These files are generated ChatGPT artifacts and are **not** a verified, integrated, shipped game project. Do not report them as production-ready or pretend that concept art is accurate orthographic modeling data. Image-generated views may disagree and need 3D inspection. GLBs were exported, but cross-asset fit and the live browser rendering have not been validated. Meshes overlap in some configurations; body under replacement panels has not been cut away. Suspension and rear motor assemblies are geometry-first placeholders. The current GLB blockouts may be visually primitive compared with polished concept images.

## IMMEDIATE GOAL FOR THE FORGE
Acknowledge and integrate Project: Baja's new name, approved visual decisions, starter Bug, asset inventory, and current R3F viewer into the existing Forge documentation, without reopening mechanics or inventing new phases. Mark the viewer/GLBs as **unverified prototypes**. Then give a narrow Claude Code kickoff task: launch the existing asset viewer, verify that it actually runs, inspect the visual alignment and geometry, report issues, and fix immediate viewer/integration bugs before extending scope. Do NOT silently decide a new engine, backend, repo, gameplay loop, marketplace data model or milestone plan.

## FIRST CLAUDE CODE IMPLEMENTATION TASK
1. Open/extract `OffRoad_Bug_Asset_Viewer_v01.zip` into a new local working directory, or integrate it into the actual designated repository if already defined by the Forge. Do not overwrite unrelated existing work.
2. Inspect README, package.json, `src/main.jsx`, `src/style.css`, and `public/models` before making changes.
3. With current supported Node/npm installed, run `npm install`, `npm run dev`, and `npm run build`; report exact output and failures. If deps are incompatible, use the smallest compatible adjustments.
4. Verify the classic Bug loads at startup, orbit/pan/zoom work, each of 16 GLBs loads on toggle, Stock/Trail/Baja previews work, wireframe/grid and click-to-inspect work. Inspect console and network errors.
5. Correct user-facing UI label to 'Project: Baja — Vehicle Asset Lab' while leaving mesh filenames stable.
6. Check meshes' relative scale, origin, orientation, fender/hood locations, and visible intersections. Track concrete defects. Fix viewer bugs, but do not claim repaired production vehicle geometry unless actually changed and tested.
7. Keep generated-model GLBs organized under public/models with an inventory file noting whether each is blockout/validated. Avoid premature refactors or implementation of gameplay systems.
8. Provide a session summary that Chris can paste back to the Forge: exact files changed, commands and results, screenshots/visual observations, known limitations, next recommended engineering action, and unresolved design decisions explicitly routed to the Forge.

## SUCCESS CRITERIA FOR FIRST CODE SESSION
- The Vite viewer runs locally and builds successfully, or a precise reproducible blocker is documented.
- All 17 GLBs are discoverable and testable in the viewer.
- The starter Bug can be inspected through the UI; clear overlap/misalignment notes are captured.
- The repo is left clean and documented, with no invented game systems or misleading claims of production-ready art.
- A concise handback summary is prepared for the Forge.

## USER PREFERENCES
Direct, short, practical instructions. Explain exact VS Code paths and commands as needed. Prioritize visual inspection and real working files over aspirational planning. The Forge owns design; Claude Code owns implementation.
