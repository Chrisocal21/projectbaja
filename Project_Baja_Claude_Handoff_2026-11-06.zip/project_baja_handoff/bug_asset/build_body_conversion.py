"""VEH_001 Baja body conversion — procedural modular GLB *blockout* pack.
Coordinate convention copied from VEH_001_Bug_Base_v01: meters, X transverse,
Y up, +Z forward, origin at ground center. Independent meshes, separate GLBs.
These are silhouette/fit prototypes, not production topology or final textures.
"""
from pathlib import Path
import numpy as np
import trimesh
from trimesh.creation import cylinder, box, icosphere

ROOT = Path(__file__).resolve().parent
BLUE=(115,156,166,255)
GRAY=(119,122,120,255)
FIBER=(193,178,149,255)
DARK=(36,37,35,255)
STEEL=(104,105,100,255)
ENGINE=(84,83,77,255)
RUST=(107,78,57,255)


def add(sc, name, mesh, color):
    mesh.visual = trimesh.visual.ColorVisuals(mesh, vertex_colors=np.tile(np.array(color,dtype=np.uint8), (len(mesh.vertices),1)))
    sc.add_geometry(mesh, geom_name=name,node_name=name)

def segments(sc,name,points,radius,color,sections=10):
    ms=[]
    for a,b in zip(points[:-1],points[1:]):
        a=np.asarray(a,dtype=float); b=np.asarray(b,dtype=float)
        v=b-a
        if np.linalg.norm(v)<1e-8:continue
        m=cylinder(radius=radius, height=np.linalg.norm(v), sections=sections)
        m.apply_transform(trimesh.geometry.align_vectors([0,0,1],v))
        m.apply_translation((a+b)/2)
        ms.append(m)
    if ms:add(sc,name,trimesh.util.concatenate(ms),color)

def surface(sc, name, grid, color, close_back=True):
    """Regular grid vertices [row][col][xyz], double-sided to survive winding differences."""
    arr=np.asarray(grid,dtype=float)
    u,v,_=arr.shape
    fs=[]
    for i in range(u-1):
        for j in range(v-1):
            a=i*v+j;b=a+1;c=(i+1)*v+j;d=c+1
            fs.extend([[a,c,b],[b,c,d]])
    if close_back:
        fs+= [f[::-1] for f in fs]
    add(sc,name,trimesh.Trimesh(vertices=arr.reshape(-1,3),faces=np.array(fs),process=False),color)

def curved_fender(sc, axle, side, flare=False):
    """Trimmed wheel arch and optional extended fiberglass lip, wheel-center aligned."""
    sign=-1 if side=='L' else 1
    zc=1.19 if axle=='F' else -1.19
    # Replacement follows the stock wheel location, but its top terminates lower
    # than the full original fender, exposing the front/rear cut-away areas.
    theta=np.linspace(.02,np.pi-.02,26)
    # two bands: close to body and outer wing edge; top arch radius ~0.45m
    strip=[]
    for u in range(len(theta)):
        a=theta[u]
        radius=.475 if not flare else .525
        yy=.34+radius*np.sin(a)
        zz=zc+radius*np.cos(a)
        inner=sign*(.68 if not flare else .72)
        outer=sign*(.84 if not flare else 1.00)
        # arch rolled inward into central body at the rear/front edges
        strip.append([[inner, yy-.045,zz],[sign*(abs(inner)+abs(outer))/2,yy+.02,zz],[outer,yy-.065,zz]])
    surface(sc, f'BODY_Baja{ "Wide" if flare else "Cut" }_Fender_{axle}{side}',strip,FIBER if flare else (GRAY if axle=='F' and side=='L' else BLUE))
    outer=sign*(1.0 if flare else .84)
    rr=.525 if flare else .475
    lip=[(outer,.34+rr*np.sin(a)-.065,zc+rr*np.cos(a)) for a in theta]
    segments(sc,f'TRIM_FenderLip_{axle}{side}',lip,.014,DARK if flare else STEEL)
    # raised short edge plates close the cut, not a full rounded street wing
    for ind,n in [(0,'FrontCut'),(-1,'RearCut')]:
        z=zc+rr*np.cos(theta[ind])
        y=.34+rr*np.sin(theta[ind])-.065
        segments(sc,f'TRIM_{n}_{axle}{side}',[(sign*.68,y+.03,z),(outer,y,z)],.018,DARK)

def export(sc, filename):
    dst=ROOT/filename;sc.export(dst)
    loaded=trimesh.load(dst,force='scene')
    assert len(loaded.geometry)>0 and dst.stat().st_size>500
    print(f'{filename}: {len(loaded.geometry)} meshes, {sum(len(m.faces) for m in loaded.geometry.values())} triangles, {dst.stat().st_size} bytes')

# 1. Cut metal fenders — replacement for original curved street fender mesh nodes.
s=trimesh.Scene()
for a in ('F','R'):
    for side in ('L','R'):curved_fender(s,a,side)
export(s,'PART_007_CutBajaFenders.glb')

# 2. Shortened front hood with a softly curved crown and cut lower apron trim.
s=trimesh.Scene()
zvals=np.linspace(1.12,1.72,15)
longitudinal=[]
for z in zvals:
    t=(z-1.12)/(.60)
    width=.49-.11*t
    base=.985-.21*t
    longitudinal.append([[x*width,base+.035*(1-x*x),z] for x in np.linspace(-1,1,13)])
surface(s,'BODY_BajaShortHood',longitudinal,BLUE)
segments(s,'TRIM_HoodEdge',[(x*(.49-.11),.985-.21+.035*(1-x*x),1.72) for x in np.linspace(-1,1,15)],.014,STEEL)
segments(s,'TRIM_HoodCenter',[(0,.985+.035,1.12),(0,.88+.035,1.48),(0,.775+.035,1.72)],.008,STEEL)
# stylized clipped lower nose skin beneath the short hood
surface(s,'BODY_CutFrontApron',[[[-.37,.59,1.76],[0,.55,1.78],[.37,.59,1.76]],[[-.32,.48,1.76],[0,.45,1.78],[.32,.48,1.76]]],BLUE)
export(s,'PART_008_ShortenedFrontHood.glb')

# 3. Rear engine access opening / removable frame and short vented cover.
s=trimesh.Scene()
# The base has a full rear lid; remove/hide that while mounting this short lid.
for side,sg in [('L',-1),('R',1)]:
    segments(s,f'BODY_EngineOpeningRail_{side}',[(sg*.43,.98,-1.27),(sg*.47,.90,-1.54),(sg*.32,.74,-1.94)],.024,STEEL)
segments(s,'BODY_EngineOpeningUpper', [(-.43,.98,-1.27),(0,1.00,-1.26),(.43,.98,-1.27)],.025,STEEL)
segments(s,'BODY_EngineOpeningLower', [(-.32,.74,-1.94),(0,.70,-1.97),(.32,.74,-1.94)],.025,STEEL)
# a half-height deck lid held above a visibly exposed rear engine
vent=[]
for z in np.linspace(-1.26,-1.52,9):
    t=(-z-1.26)/.26
    vent.append([[x*(.43+.035*t),.97-.08*t+.025*(1-x*x),z] for x in np.linspace(-1,1,11)])
surface(s,'BODY_BajaPartialDeckLid',vent,BLUE)
for i,z in enumerate(np.linspace(-1.36,-1.48,4)):
    segments(s,f'TRIM_DeckVent_{i}',[(-.23,.95,z),(.23,.95,z)],.009,DARK)
# Basic rear-engine silhouette proxy: actual engine will be its own later GLB
m=box(extents=[.62,.39,.42]);m.apply_translation([0,.62,-1.64]);add(s,'ENGINE_PlaceholderBlock',m,ENGINE)
for side,sg in [('L',-1),('R',1)]:
    m=cylinder(radius=.12,height=.28,sections=16)
    m.apply_transform(trimesh.geometry.align_vectors([0,0,1],[1,0,0]));m.apply_translation([sg*.31,.64,-1.65])
    add(s,f'ENGINE_PlaceholderHead_{side}',m,STEEL)
segments(s,'TRIM_RearLowerEdge',[(-.4,.56,-1.93),(0,.55,-1.96),(.4,.56,-1.93)],.02,DARK)
export(s,'PART_009_RearEngineOpening.glb')

# 4. Wide fiberglass-style replacements, separate alternative to cut metal set.
s=trimesh.Scene()
for a in ('F','R'):
    for side in ('L','R'):curved_fender(s,a,side,flare=True)
export(s,'PART_010_FiberglassWideFenders.glb')

# 5. Lower side-panel / rocker protectors, a separate optional conversion.
s=trimesh.Scene()
for side,sg in [('L',-1),('R',1)]:
    grid=[]
    for z in np.linspace(-.69,.72,16):
        grid.append([[sg*.805,.54,z],[sg*.845,.41,z],[sg*.84,.32,z]])
    surface(s,f'BODY_RockerGuard_{side}',grid,FIBER)
    segments(s,f'TRIM_RockerRail_{side}',[(sg*.88,.34,-.70),(sg*.88,.34,.70)],.023,DARK)
export(s,'PART_011_RockerGuards.glb')
