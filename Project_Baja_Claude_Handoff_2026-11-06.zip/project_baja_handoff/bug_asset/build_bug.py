import numpy as np, trimesh
from trimesh.creation import cylinder, box, icosphere
from trimesh.transformations import rotation_matrix
from pathlib import Path

OUT=Path(__file__).resolve().parent
scene=trimesh.Scene()
BLUE=[0.36,0.56,0.63,1]; PRIMER=[0.43,0.44,0.43,1]; METAL=[0.50,0.50,0.49,1]; RUBBER=[0.105,0.105,0.105,1]; GLASS=[0.13,0.22,0.25,1]; TRIM=[0.22,0.22,0.20,1]; LIGHT=[0.78,0.75,0.63,1]; RED=[0.64,0.13,0.08,1]; SEAT=[0.38,0.30,0.23,1]

def add(name,mesh,color):
 mesh.visual=trimesh.visual.ColorVisuals(mesh,vertex_colors=np.tile((np.array(color)*255).astype(np.uint8),(len(mesh.vertices),1)))
 scene.add_geometry(mesh,geom_name=name,node_name=name)

def uvball(center,scale, color,name,sub=2):
 m=icosphere(subdivisions=sub,radius=1)
 m.apply_scale(scale);m.apply_translation(center);add(name,m,color)

def cub(name,center,size,col):
 m=box(extents=size);m.apply_translation(center);add(name,m,col)

def rings_mesh(rings,radial=20):
 # list (z,center_y, width_x, radius_y) ellipsoid cross-section
 verts=[]
 for z,cy,rx,ry in rings:
  for i in range(radial):
   a=2*np.pi*i/radial
   verts.append([rx*np.cos(a),cy+ry*np.sin(a),z])
 faces=[]
 for j in range(len(rings)-1):
  for i in range(radial):
   a=j*radial+i;b=j*radial+(i+1)%radial;c=(j+1)*radial+i;d=(j+1)*radial+(i+1)%radial
   faces += [[a,b,c],[b,d,c]]
 faces += [[0,i+1,i] for i in range(1,radial-1)]
 start=(len(rings)-1)*radial
 faces += [[start,start+i,start+i+1] for i in range(1,radial-1)]
 return trimesh.Trimesh(vertices=verts,faces=faces,process=False)

def tube(name,pts,r,color,segments=8):
 # smooth tubular path using sphere/cylinders all as one mesh
 out=[]
 for a,b in zip(pts[:-1],pts[1:]):
  a=np.array(a);b=np.array(b);v=b-a;length=np.linalg.norm(v)
  if length<1e-6:continue
  m=cylinder(radius=r,height=length,sections=segments)
  m.apply_transform(trimesh.geometry.align_vectors([0,0,1],v))
  m.apply_translation((a+b)/2)
  out.append(m)
 if out:add(name,trimesh.util.concatenate(out),color)

def patch(name,pts,col):
 # fan triangulate convex-ish polygon
 verts=np.array(pts,dtype=float)
 faces=[[0,i,i+1] for i in range(1,len(verts)-1)]
 add(name,trimesh.Trimesh(vertices=verts,faces=faces,process=False),col)

# z front = +; x across; y up. Starter dimensions approx 4.1 long, 1.62 wide, 1.53 high.
# Two separate lobes define the characteristic rounded nose and sloping rear deck.
body_rings=[(-2.05,0.72,.25,.17),(-1.88,.73,.57,.29),(-1.60,.76,.72,.38),(-1.25,.76,.78,.39),(-.75,.75,.79,.39),(0,.74,.80,.39),(.70,.74,.78,.38),(1.25,.73,.72,.36),(1.63,.71,.61,.31),(1.91,.66,.40,.23),(2.05,.64,.18,.12)]
add('BODY_Main',rings_mesh(body_rings,32),BLUE)
# curved cabin roof with sloping windshield and rear window
cabin=[(-1.46,1.01,.40,.04),(-1.18,1.10,.56,.23),(-.91,1.17,.62,.31),(-.55,1.18,.64,.34),(.02,1.18,.66,.35),(.47,1.18,.64,.33),(.80,1.12,.57,.26),(1.12,1.00,.40,.05)]
add('BODY_Cabin_Roof',rings_mesh(cabin,32),BLUE)
# thin window patches on sides, approximating classic 2 door with rear quarter glass
for s,side in [(-1,'L'),(1,'R')]:
 patch('GLASS_Door_'+side,[(s*.645,1.05,.12),(s*.652,1.37,.12),(s*.59,1.43,.49),(s*.55,1.07,.67)],GLASS)
 patch('GLASS_Quarter_'+side,[(s*.63,1.05,-.86),(s*.60,1.39,-.79),(s*.61,1.43,-.40),(s*.66,1.05,-.35)],GLASS)
 patch('BODY_Door_'+side,[(s*.798,.50,-.35),(s*.803,1.02,-.35),(s*.802,1.03,.72),(s*.799,.48,.72)],BLUE)
 tube('TRIM_DoorOutline_'+side,[(s*.809,.49,-.35),(s*.812,1.03,-.35),(s*.812,1.03,.72),(s*.809,.49,.72)],.009,TRIM)
 cub('EXTERIOR_DoorHandle_'+side,[s*.822,.79,.18],[.04,.035,.14],METAL)
 # mirror body
 uvball([s*.81,1.04,.82],[.10,.065,.075],METAL,'EXTERIOR_Mirror_'+side)
# windscreen and rear glass dark curved patches at appropriate z
patch('GLASS_Windshield',[(-.52,1.01,1.09),(.52,1.01,1.09),(.57,1.36,.72),(.36,1.46,.55),(-.36,1.46,.55),(-.57,1.36,.72)],GLASS)
patch('GLASS_RearWindow',[(-.52,1.00,-1.31),(.52,1.00,-1.31),(.52,1.35,-1.13),(.33,1.47,-.97),(-.33,1.47,-.97),(-.52,1.35,-1.13)],GLASS)
# hood and rear lid are separate overlaid contour polygons
patch('BODY_Hood_Front',[(-.46,.99,1.12),(.46,.99,1.12),(.54,.90,1.43),(.44,.74,1.82),(-.44,.74,1.82),(-.54,.90,1.43)],BLUE)
patch('BODY_Engine_Lid_Rear',[(-.43,.97,-1.25),(.43,.97,-1.25),(.48,.89,-1.53),(.31,.72,-1.94),(-.31,.72,-1.94),(-.48,.89,-1.53)],BLUE)
# metal thin center trim nose
tube('TRIM_HoodCenter',[(0,1.00,1.12),(0,.92,1.42),(0,.76,1.82)],.012,METAL)
# wheels centers at +/-0.76, z front +1.18, rear -1.18; axle along x
for front,z in [('F',1.19),('R',-1.19)]:
 for s,side in [(-1,'L'),(1,'R')]:
  x=s*.76
  tire=cylinder(radius=.335,height=.19,sections=32)
  tire.apply_transform(rotation_matrix(np.pi/2,[0,1,0]));tire.apply_translation([x,.34,z]);add(f'WHEEL_{front}{side}_Tire',tire,RUBBER)
  rim=cylinder(radius=.196,height=.198,sections=32)
  rim.apply_transform(rotation_matrix(np.pi/2,[0,1,0]));rim.apply_translation([x,.34,z]);add(f'WHEEL_{front}{side}_SteelRim',rim,METAL)
  hub=cylinder(radius=.06,height=.207,sections=16)
  hub.apply_transform(rotation_matrix(np.pi/2,[0,1,0]));hub.apply_translation([x,.34,z]);add(f'WHEEL_{front}{side}_Hub',hub,TRIM)
  # each stock fender is a distinct curved arch. Primer left front only.
  ts=np.linspace(-.12,np.pi+.12,20)
  pts=[(s*.77,.35+.44*np.sin(t),z+.44*np.cos(t)) for t in ts]
  tube(f'BODY_Fender_{front}{side}',pts,.11,PRIMER if (front=='F' and side=='L') else BLUE,12)
# stock bumpers and overriders
for face,z in [('Front',2.04),('Rear',-2.03)]:
 tube('EXTERIOR_Bumper_'+face,[(-.76,.39,z),(-.55,.36,z+(.08 if face=='Front' else -.08)),(0,.36,z+(.11 if face=='Front' else -.11)),(.55,.36,z+(.08 if face=='Front' else -.08)),(.76,.39,z)],.047,METAL,12)
 for x in [-.44,.44]:
  tube('EXTERIOR_Overrider_'+face+('_L' if x<0 else '_R'),[(x,.30,z),(x,.52,z)],.034,METAL)
# headlights located on front fenders
for s,side in [(-1,'L'),(1,'R')]:
 uvball([s*.62,.85,1.63],[.17,.17,.065],LIGHT,'EXTERIOR_Headlight_'+side,3)
 uvball([s*.62,.93,-1.84],[.11,.16,.055],RED,'EXTERIOR_Taillight_'+side)
 uvball([s*.69,1.00,1.35],[.07,.04,.085],[.78,.41,.06,1],'EXTERIOR_TurnSignal_'+side)
# running boards
for s,side in [(-1,'L'),(1,'R')]:
 cub('TRIM_RunningBoard_'+side,[s*.82,.31,0],[.16,.065,1.26],TRIM)
# underbody shadow box as spatial reference; not detailed chassis
cub('BODY_Floorpan',[0,.37,0],[1.22,.09,2.75],TRIM)
# interior silhouette through glass
for s,side in [(-1,'L'),(1,'R')]:
 cub('INTERIOR_Seat_'+side,[s*.33,.72,-.07],[.41,.52,.42],SEAT)

path=OUT/'VEH_001_Bug_Base_v01.glb'
scene.export(path)
print(path, path.stat().st_size, 'bytes', len(scene.geometry),'meshes')
